# StarterKit

File Starter Bootstrap versi Terbaru untuk Praktikum DPP 2020

### Rules

* Format Commit: NRP #AngkaCommitKeBerapa
   > Contoh - Kalian melakukan commit pertama, maka keterangan commit adalah **05211640000999 #1**
* Diperkenankan untuk mengambil komponen2 dari dokumentasi bootstrap
* TIDAK DIPERKENANKAN PLAGIARISME ATAU 100% COPY-PASTE FILE JADI (HANYA UBAH WARNA, TEXT, DKK)


